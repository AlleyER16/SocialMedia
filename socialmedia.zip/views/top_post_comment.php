<%-- 
    Document   : top_post_comment
    Created on : Jun 6, 2020, 6:07:03 AM
    Author     : REHOBOTH
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
                                <div class="row">
                                    <div class="col-md-2 col-sm-2 col-xs-3">
                                        <img src="images/img_avatar.png" width="100%" class="img-circle" style="max-height: 50px;"/>
                                    </div>
                                    <div class="col-md-10 col-sm-10 col-xs-9">
                                        <div class="panel-body w3-light-grey w3-border w3-round-xlarge" style="border-radius: 50%;"><b>Akashi</b><br/>Useless Post</div>
                                    </div>
                                </div>
