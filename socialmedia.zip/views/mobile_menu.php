<div id="mobile_menu">

    <div class="container-fluid navbar-inverse">
        <div class="row">
            <div class="col-xs-12">
                <div class="navbar-brand">Hidden</div>
            </div>
        </div>
    </div>


    <div class="container w3-margin-top">
        <div class="col-md-12 w3-border w3-margin-bottom" style="padding: 20px;">
            <a href="profile.php">Profile</a>
        </div>
        <div class="col-md-12 w3-border w3-margin-bottom" style="padding: 20px;">
            <a href="home.php">Home</a>
        </div>
        <div class="col-md-12 w3-border w3-margin-bottom" style="padding: 20px;">
            <a href="chat.php">Chat <span class="unread_chat_count"></span></a>
        </div>
        <div class="col-md-12 w3-border w3-margin-bottom" style="padding: 20px;">
            <a href="friends.php">Friends Requests <span class="friend_requests_count"></span></a>
        </div>
        <div class="col-md-12 w3-border w3-margin-bottom" style="padding: 20px;">
            <a href="settings.php">Settings</a>
        </div>
        <div class="col-md-12 w3-border w3-margin-bottom" style="padding: 20px;">
            <a href="logout.php">Logout</a>
        </div>
    </div>
</div>
