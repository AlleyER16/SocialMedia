
            <div class="container-fluid navbar-default navbar-fixed-top navbar-inverse">
                <div class="row">
                    <div class="col-xs-3">
                        <div class="navbar-brand">SM</div>
                    </div>
                    <div class="col-xs-6" style="overflow: auto; white-space: nowrap;">
                        <div class="navbar-brand">Rehoboth Micah-Daniels</div>
                    </div>
                    <div class="col-xs-2 w3-padding-top">
                        <button class="btn btn-success" onclick="$('#mobile_menu').slideToggle('slow');">Menu</button>
                    </div>
                </div>
            </div>

            <div class="container-fluid navbar-inverse">
                <div class="row">
                    <div class="col-xs-3">
                        <div class="navbar-brand">SM</div>
                    </div>
                    <div class="col-xs-6" style="overflow: auto; white-space: nowrap;">
                        <div class="navbar-brand">Rehoboth Micah-Daniels</div>
                    </div>
                    <div class="col-xs-2 w3-padding-top">
                        <button class="btn btn-success">Menu</button>
                    </div>
                </div>
            </div>
