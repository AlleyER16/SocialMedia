<div class="img-thumbnail">
    <img src="assets/images/pallor.jpg" width="100%"/>
    <div class="caption w3-padding">
        <b>Olgab Decors</b>
        <p>This is a one touch decoration agency which provide great services</p>
    </div>
</div>
