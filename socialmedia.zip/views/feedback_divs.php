<div id="show_loading">
    <div class="col-md-12 text-center">
        <button class="btn" style="background-color: black; color: white; border-radius: 25px;">
            <span class="fa fa-spinner fa-spin"></span>
        </button>
    </div>
</div>

<div id="show_operation_message">
    <div class="col-md-12 text-center">
        <button class="btn" id="message" style="background-color: black; color: white; border-radius: 25px;">
            
        </button>
    </div>
</div>
