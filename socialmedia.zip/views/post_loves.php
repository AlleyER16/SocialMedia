<div class="row">
    <div class="col-md-2">
        <img src="images/img_avatar.png" class="img-circle" width="100%"/>
    </div>
    <div class="col-md-10 w3-padding-top">
        Akashi Senpai
    </div>
</div>
