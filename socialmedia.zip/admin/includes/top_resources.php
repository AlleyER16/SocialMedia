<link type="text/css" rel="stylesheet" href="assets/css/bootstrap.min.css"/>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300&display=swap" rel="stylesheet">

<style type="text/css">
    *,h1,h3{
        font-family: 'Poppins', sans-serif;
    }
</style>
