<link type="text/css" rel="stylesheet" href="assets/css/sidebarNavigation.css"/>
<link type="text/css" rel="stylesheet" href="assets/css/bootstrap.css"/>
<link type="text/css" rel="stylesheet" href="assets/css/w3.css"/>
<link type="text/css" rel="stylesheet" href="assets/css/style.css"/>
<link type="text/css" rel="stylesheet" href="assets/css/font-awesome.css"/>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300&display=swap" rel="stylesheet">

<style type="text/css">
    *, h1, h3, h6{
        font-family: 'Poppins', sans-serif;
    }
</style>

<script src="assets/js/sidebarNavigation.js"></script>
<script src="assets/js/jquery-1.11.1.min.js"></script>
<script src="assets/js/bootstrap.js"></script>
