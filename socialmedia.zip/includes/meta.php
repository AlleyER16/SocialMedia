<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<meta name="keywords" content="RChat.com, RChat, Chatting Applications"/>
<meta name="X-UA-Compactible" content="IE=edge"/>
